Nguyễn Ngọc Tâm 
dựa theo command bên dofactory demo mywworld về text văn bản đơn giản 
